sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/m/MessageBox",
		"./utilities",
		"sap/ui/core/routing/History"
	], function(BaseController, MessageBox, Utilities, History) {
		"use strict";
		return BaseController.extend("com.sap.build.standard.effiPointDriverCopy.controller.AppMain", {
			handleRouteMatched: function(oEvent) {
				var oParams = {};
				if (oEvent.mParameters.data.context) {
					this.sContext = oEvent.mParameters.data.context;
					var oPath;
					if (this.sContext) {
						oPath = {
							path: "/" + this.sContext,
							parameters: oParams
						};
						this.getView().bindObject(oPath);
					}
				}
			},
			_onPageNavButtonPress: function() {
				var oDialog = this.getView().getContent()[0];
				return new Promise(function(fnResolve) {
					oDialog.attachEventOnce("afterClose", null, fnResolve);
					oDialog.close();
				});
			},
			_onRowPress: function(oEvent) {
				var sDialogName = "Dialog1";
				this.mDialogs = this.mDialogs || {};
				var oDialog = this.mDialogs[sDialogName];
				var oSource = oEvent.getSource();
				var oBindingContext = oSource.getBindingContext();
				var sPath = oBindingContext ? oBindingContext.getPath() : null;
				var oView;
				if (!oDialog) {
					this.getOwnerComponent().runAsOwner(function() {
						oView = sap.ui.xmlview({
							viewName: "com.sap.build.standard.effiPointDriverCopy.view." + sDialogName
						});
						this.getView().addDependent(oView);
						oView.getController().setRouter(this.oRouter);
						oDialog = oView.getContent()[0];
						this.mDialogs[sDialogName] = oDialog;
					}.bind(this));
				}
				return new Promise(function(fnResolve) {
					oDialog.attachEventOnce("afterOpen", null, fnResolve);
					oDialog.open();
					if (oView) {
						oDialog.attachAfterOpen(function() {
							oDialog.rerender();
						});
					} else {
						oView = oDialog.getParent();
					}
					var oModel = this.getView().getModel();
					if (oModel) {
						oView.setModel(oModel);
					}
					if (sPath) {
						var oParams = oView.getController().getBindingParameters();
						oView.bindObject({
							path: sPath,
							parameters: oParams
						});
					}
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onTableItemPress: function(oEvent) {
				var oBindingContext = oEvent.getParameter("listItem").getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("AppOrderTracking", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			doNavigate: function(sRouteName, oBindingContext, fnPromiseResolve, sViaRelation) {
				var sPath = oBindingContext ? oBindingContext.getPath() : null;
				var oModel = oBindingContext ? oBindingContext.getModel() : null;
				var sEntityNameSet;
				if (sPath !== null && sPath !== "") {
					if (sPath.substring(0, 1) === "/") {
						sPath = sPath.substring(1);
					}
					sEntityNameSet = sPath.split("(")[0];
				}
				var sNavigationPropertyName;
				var sMasterContext = this.sMasterContext ? this.sMasterContext : sPath;
				if (sEntityNameSet !== null) {
					sNavigationPropertyName = sViaRelation || this.getOwnerComponent().getNavigationPropertyForNavigationWithContext(sEntityNameSet,
						sRouteName);
				}
				if (sNavigationPropertyName !== null && sNavigationPropertyName !== undefined) {
					if (sNavigationPropertyName === "") {
						this.oRouter.navTo(sRouteName, {
							context: sPath,
							masterContext: sMasterContext
						}, false);
					} else {
						oModel.createBindingContext(sNavigationPropertyName, oBindingContext, null, function(bindingContext) {
							if (bindingContext) {
								sPath = bindingContext.getPath();
								if (sPath.substring(0, 1) === "/") {
									sPath = sPath.substring(1);
								}
							} else {
								sPath = "undefined";
							}
							// If the navigation is a 1-n, sPath would be "undefined" as this is not supported in Build
							if (sPath === "undefined") {
								this.oRouter.navTo(sRouteName);
							} else {
								this.oRouter.navTo(sRouteName, {
									context: sPath,
									masterContext: sMasterContext
								}, false);
							}
						}.bind(this));
					}
				} else {
					this.oRouter.navTo(sRouteName);
				}
				if (typeof fnPromiseResolve === "function") {
					fnPromiseResolve();
				}
			},
			_onStandardTilePress: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("DetailedAchievementView", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onStandardTilePress1: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("DetailedAchievementView", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onStandardTilePress2: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("DetailedAchievementView", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onStandardTilePress3: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("DetailedAchievementView", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onStandardTilePress4: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("Dialog5", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onStandardTilePress5: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("DetailedAchievementView", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onStandardTilePress6: function(oEvent) {
				var sDialogName = "Dialog8";
				this.mDialogs = this.mDialogs || {};
				var oDialog = this.mDialogs[sDialogName];
				var oSource = oEvent.getSource();
				var oBindingContext = oSource.getBindingContext();
				var sPath = oBindingContext ? oBindingContext.getPath() : null;
				var oView;
				if (!oDialog) {
					this.getOwnerComponent().runAsOwner(function() {
						oView = sap.ui.xmlview({
							viewName: "com.sap.build.standard.effiPointDriverCopy.view." + sDialogName
						});
						this.getView().addDependent(oView);
						oView.getController().setRouter(this.oRouter);
						oDialog = oView.getContent()[0];
						this.mDialogs[sDialogName] = oDialog;
					}.bind(this));
				}
				return new Promise(function(fnResolve) {
					oDialog.attachEventOnce("afterOpen", null, fnResolve);
					oDialog.open();
					if (oView) {
						oDialog.attachAfterOpen(function() {
							oDialog.rerender();
						});
					} else {
						oView = oDialog.getParent();
					}
					var oModel = this.getView().getModel();
					if (oModel) {
						oView.setModel(oModel);
					}
					if (sPath) {
						var oParams = oView.getController().getBindingParameters();
						oView.bindObject({
							path: sPath,
							parameters: oParams
						});
					}
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			_onSegmentedButtonItemPress: function(oEvent) {
				var oBindingContext = oEvent.getSource().getBindingContext();
				return new Promise(function(fnResolve) {
					this.doNavigate("AppMainO", oBindingContext, fnResolve, "");
				}.bind(this)).catch(function(err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			},
			updateBindingOptions: function(sCollectionId, oBindingData, sSourceId) {
				this.mBindingOptions[sCollectionId] = this.mBindingOptions[sCollectionId] || {};
				var aSorters = oBindingData.sorters === undefined ? this.mBindingOptions[sCollectionId].sorters : oBindingData.sorters;
				var oGroupby = oBindingData.groupby === undefined ? this.mBindingOptions[sCollectionId].groupby : oBindingData.groupby;
				// 1) Update the filters map for the given collection and source
				this.mBindingOptions[sCollectionId].sorters = aSorters;
				this.mBindingOptions[sCollectionId].groupby = oGroupby;
				this.mBindingOptions[sCollectionId].filters = this.mBindingOptions[sCollectionId].filters || {};
				this.mBindingOptions[sCollectionId].filters[sSourceId] = oBindingData.filters || [];
				// 2) Reapply all the filters and sorters
				var aFilters = [];
				for (var key in this.mBindingOptions[sCollectionId].filters) {
					aFilters = aFilters.concat(this.mBindingOptions[sCollectionId].filters[key]);
				}
				// Add the groupby first in the sorters array
				if (oGroupby) {
					aSorters = aSorters ? [oGroupby].concat(aSorters) : [oGroupby];
				}
				var aFinalFilters = aFilters.length > 0 ? [new sap.ui.model.Filter(aFilters, true)] : undefined;
				return {
					filters: aFinalFilters,
					sorters: aSorters
				};
			},
			onInit: function() {
				this.mBindingOptions = {};
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				this.oRouter.getTarget("AppMain").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
				var oView = this.getView();
				var oModel = new sap.ui.model.json.JSONModel();
				oView.setModel(oModel, "staticDataModel");

				function dateDimensionFormatter(dimensionValue) {
					if (dimensionValue instanceof Date) {
						var oFormat = sap.ui.core.format.DateFormat.getDateInstance({
							style: "short"
						});
						return oFormat.format(dimensionValue);
					}
					return dimensionValue;
				}
				var oData = [{
					"dim0": "India",
					"mea0": "296"
				}, {
					"dim0": "Canada",
					"mea0": "133"
				}, {
					"dim0": "USA",
					"mea0": "489"
				}, {
					"dim0": "Japan",
					"mea0": "270"
				}, {
					"dim0": "Germany",
					"mea0": "350"
				}];
				oView.getModel("staticDataModel").setData({
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143": oData
				}, true);
				this.oBindingParameters = {
					"path": "/AggregatedStatusDataSet",
					"parameters": {}
				};
				oView.byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143"
				).bindData(this.oBindingParameters);
				var aDimensions = oView.byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143"
				).getDimensions();
				aDimensions.forEach(function(oDimension) {
					oDimension.setTextFormatter(dateDimensionFormatter);
				});
				this.mBindingOptions = {};
				var oBindingData, aPropertyFilters, oBindingOptions;
				oBindingData = {};
				oBindingData.sorters = [];
				oBindingData.sorters.push(new sap.ui.model.Sorter("StatusData", false, false));
				oBindingOptions = this.updateBindingOptions(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143",
					oBindingData);
				var oBindingInfo = this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143"
				).getBindingInfo("data");
				this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143"
				).bindAggregation("data", {
					model: oBindingInfo.model,
					path: oBindingInfo.path,
					parameters: oBindingInfo.parameters,
					template: oBindingInfo.template,
					sorter: oBindingOptions.sorters,
					filters: oBindingOptions.filters
				});
				oBindingData = {};
				oBindingData.filters = [];
				aPropertyFilters = [];
				aPropertyFilters.push(new sap.ui.model.Filter("AlertStatus", "EQ", "Active"));
				oBindingData.filters.push(new sap.ui.model.Filter(aPropertyFilters, false));
				oBindingData.sorters = [];
				oBindingData.sorters.push(new sap.ui.model.Sorter("AlertStatus", false, false));
				oBindingOptions = this.updateBindingOptions(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-build_simple_Table-1507119325623",
					oBindingData);
				var oBindingInfo = this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-build_simple_Table-1507119325623"
				).getBindingInfo("items");
				this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-build_simple_Table-1507119325623"
				).bindAggregation("items", {
					model: oBindingInfo.model,
					path: oBindingInfo.path,
					parameters: oBindingInfo.parameters,
					template: oBindingInfo.template,
					sorter: oBindingOptions.sorters,
					filters: oBindingOptions.filters
				});
				oBindingData = {};
				oBindingData.filters = [];
				aPropertyFilters = [];
				aPropertyFilters.push(new sap.ui.model.Filter("Status", "EQ", "OrderInTransit"));
				oBindingData.filters.push(new sap.ui.model.Filter(aPropertyFilters, false));
				oBindingOptions = this.updateBindingOptions(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-5-content-build_simple_Table-1507121281462",
					oBindingData);
				var oBindingInfo = this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-5-content-build_simple_Table-1507121281462"
				).getBindingInfo("items");
				this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-5-content-build_simple_Table-1507121281462"
				).bindAggregation("items", {
					model: oBindingInfo.model,
					path: oBindingInfo.path,
					parameters: oBindingInfo.parameters,
					template: oBindingInfo.template,
					sorter: oBindingOptions.sorters,
					filters: oBindingOptions.filters
				});
			},
			onAfterRendering: function() {
				var oBindingParameters, oChart;
				oChart = this.getView().byId(
					"sap_Responsive_Page_0-content-sap_m_IconTabBar-1507109784575-items-sap_m_IconTabFilter-1-content-sap_m_Panel-1507109906400-content-sap_chart_PieChart-1507117594143"
				);
				oChart.bindData(oChart.getBindingInfo("data"));
			}
			/**
			 *@memberOf com.sap.build.standard.effiPointDriverCopy.controller.AppMain
			 */
		});
	}, /* bExport= */
	true);